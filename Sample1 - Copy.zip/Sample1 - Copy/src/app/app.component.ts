import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from "@angular/router";
/* import { RouterOutlet } from '@angular/router';
import { Admin1Component } from "./components/admin1/admin1.component";
import { User1Component } from "./components/user1/user1.component"; */

//import { DataBinding3Component } from "./components/data-binding3/data-binding3.component";

/* import { NgIf4Component } from "./components/ng-if4/ng-if4.component";
import { NgFor4Component } from "./components/ng-for4/ng-for4.component"; */

/* import { NgClass5Component } from "./components/ng-class5/ng-class5.component";
import { NgStyle5Component } from "./components/ng-style5/ng-style5.component"; */

@Component({
  selector: 'app-root',
  //imports: [RouterOutlet, Admin1Component, User1Component, DataBinding3Component],
  //imports: [DataBinding3Component, NgIf4Component, NgFor4Component, NgClass5Component, NgStyle5Component],
  // imports: [NgStyle5Component],
  imports: [RouterOutlet,RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Sample1';
}
