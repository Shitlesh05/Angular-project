import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkedSignal8Component } from './linked-signal8.component';

describe('LinkedSignal8Component', () => {
  let component: LinkedSignal8Component;
  let fixture: ComponentFixture<LinkedSignal8Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LinkedSignal8Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LinkedSignal8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
