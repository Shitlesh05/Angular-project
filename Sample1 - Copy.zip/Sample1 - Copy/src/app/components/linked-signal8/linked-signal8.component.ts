import { Component, linkedSignal, signal } from '@angular/core';

@Component({
  selector: 'app-linked-signal8',
  imports: [],
  templateUrl: './linked-signal8.component.html',
  styleUrl: './linked-signal8.component.css'
})
export class LinkedSignal8Component {

  firstName = signal<string>("Shitlesh");
  lastName = signal<string>("Kaloshiya");

  fullName = linkedSignal({
    source: this.firstName,
    computation: (newVal, prevVal) => {
      //debugger;
      const fullName = newVal+" "+this.lastName()
      return fullName;
    }
  })

  user = signal({id:111, name:"Shitlesh"});

  email = linkedSignal({
    source: this.user,
    computation: user => `${user.name+user.id}@gmail.com`,
    equal:(a:any,b:any)=> a.id !== b.id
  })

  constructor() {

  }

  changeName(){
    this.firstName.set("Suraj");
  }

  changeId(){
    debugger;
    this.user.set({id:123, name:"SHitlesh"})
  }

}
