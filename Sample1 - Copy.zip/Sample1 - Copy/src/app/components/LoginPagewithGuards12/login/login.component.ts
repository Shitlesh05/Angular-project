import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginObj: any = {
    username: '',
    password: ''
  };

  apiLoginObj: any = {
    "EmailId": "",
    "Password": ""
  }
  http = inject(HttpClient)

  router = inject(Router);

  onLogin(){
  //   if(this.loginObj.username == "admin" && this.loginObj.password == "1122"){
  //     this.router.navigateByUrl("admin");
  //   }else{
  //     alert("Wrong credentials");
  //   }
  this.http.post("http://localhost:3000/users",this.apiLoginObj)
    //.subscribe((response:any) => {
    //  debugger;
    //  if(response.result) {
    //   console.log("Car added");
    //   alert("Car created Successfully");
    //   this.getAllCars();
    //  } else {
    //   console.log("car not added");
    //   alert(response.message)
    //  }
    //})  the above piece of code should be used when we use actual api
    .subscribe({
      next: (response: any) => {
        localStorage.setItem("angular user")
        alert("user login successfully!");
        this.getAllCars();  
      },
      error: (err) => {
        console.error('POST failed:', err);
        alert("Wrong Credentials");
      }
    });
  }
}
