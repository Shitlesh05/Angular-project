import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgClass5Component } from './ng-class5.component';

describe('NgClass5Component', () => {
  let component: NgClass5Component;
  let fixture: ComponentFixture<NgClass5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NgClass5Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgClass5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
