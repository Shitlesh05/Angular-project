import { DatePipe, JsonPipe, LowerCasePipe, NgFor, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { CustomPipePipe } from '../pipes/custom-pipe.pipe';


@Component({
  selector: 'app-pipes12',
  imports: [NgFor, UpperCasePipe, LowerCasePipe, JsonPipe, DatePipe, CustomPipePipe],
  templateUrl: './pipes12.component.html',
  styleUrl: './pipes12.component.css'
})
export class Pipes12Component {

  courseName: string = "Angular";

  currentDate: Date = new Date();

   cityList: string[] = ["Pune", "Nagpur", "Mumbai", "Hyderabad", "Chennai"]

  employeeList: any[] = [
    {empId: 111, name:'', city:"Pune", contact:"9876543210"},
    {empId: 222,  city:"Nagpur", contact:"0123456789"},
    {empId: 333, name:null, city:"Hyderabad", contact:"1597538524"},
    {empId: 444, name:'ABCDEF', city:"Chennai", contact:"3579518426"},
    {empId: 555, name:undefined, city:"Bangalore", contact:"8524569173"}
  ]

  studentObj: any = {
    name: 'Shitlesh',
    city: 'Hyderabad',
    mobile: 123123
  }
}
