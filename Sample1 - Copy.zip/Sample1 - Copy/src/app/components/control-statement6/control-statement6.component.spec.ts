import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlStatement6Component } from './control-statement6.component';

describe('ControlStatement6Component', () => {
  let component: ControlStatement6Component;
  let fixture: ComponentFixture<ControlStatement6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ControlStatement6Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ControlStatement6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
