import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-lifecycle-example',
  imports: [FormsModule],
  templateUrl: './lifecycle-example.component.html',
  styleUrl: './lifecycle-example.component.css'
})
export class LifecycleExampleComponent implements OnInit, AfterViewInit {
  carList: any[] = [];

  http = inject(HttpClient);

  carObj: any = {
    "id": 0,
    "model": '',
    "brand": '',
    "regno":'',
    "dailyRate": '',
    "year": '',
    "color":'',
    "carImage":''
  };

  ngOnInit(): void {
    this.getAllCars();
  }

  ngAfterViewInit(): void {
    console.log("after view init", performance.now());
  }

  getAllCars(){
    this.http.get("http://localhost:3000/cars").subscribe((result:any) => {
      this.carList = result;
    })
  }

  
  onSaveCars(){
    debugger;
    this.http.post("http://localhost:3000/cars",this.carObj)
    // .subscribe((response:any) => {
    //  debugger;
    //  if(response.result) {
    //   alert("Car created Successfully");
    //   this.getAllCars();
    //  } else {
    //   alert(response.message)
    //  }
    // })
    .subscribe({
      next: (response: any) => {
        alert("Car created successfully!");
        this.getAllCars();  
      },
      error: (err) => {
        alert("Failed to create car");
      }
    });
  }

  onEdit(data: any){
    this.carObj = { ...data };
  }

  onUpdateCars(){
    this.http.put(`http://localhost:3000/cars/${this.carObj.id}`,this.carObj)
    // .subscribe((response:any) => {
    //  debugger;
    //  if(response.result) {
    //   alert("Car Updated Successfully");
    //   this.getAllCars();
    //  } else {
    //   alert(response.message)
    //  }
    // })
    .subscribe({
      next: (response: any) => {
        alert("Car Updated successfully!");
        this.getAllCars();  
      },
      error: (err) => {
        alert("Failed to update car");
      }
    });
  }

  onDeleteCars(id: number){
    const isDelete = confirm("Are you sure you want to delete?");
    if(isDelete == true){
      this.http.delete(`http://localhost:3000/cars/${id}`)
    //   .subscribe((response:any) => {
    //  debugger;
    //  if(response.result) {
    //   alert("Car Deleted Successfully");
    //   this.getAllCars();
    //  } else {
    //   alert(response.message)
    //  }
    // })
    .subscribe({
      next: (response: any) => {
        alert("Car Deleted successfully!");
        this.getAllCars();  
      },
      error: (err) => {
        alert("Failed to delete car");
      }
    });
    }
  }
}
