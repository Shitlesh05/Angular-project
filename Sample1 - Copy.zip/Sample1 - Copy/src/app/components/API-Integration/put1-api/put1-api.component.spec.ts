import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Put1ApiComponent } from './put1-api.component';

describe('Put1ApiComponent', () => {
  let component: Put1ApiComponent;
  let fixture: ComponentFixture<Put1ApiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Put1ApiComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Put1ApiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
