import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgStyle5Component } from './ng-style5.component';

describe('NgStyle5Component', () => {
  let component: NgStyle5Component;
  let fixture: ComponentFixture<NgStyle5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NgStyle5Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgStyle5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
