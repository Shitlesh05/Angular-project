export class Car {
    id: number;
    model: string;
    brand: string;
    regno: string;
    dailyRate: number;
    year: number;
    color: string;
    carImage: string;

    constructor() {
        this.id= 0;
        this.model= "";
        this.brand= "";
        this.regno= "";
        this.dailyRate= 0;
        this.year= 0;
        this.color= "";
        this.carImage= "";
    }
}

export interface ICarList {
    id: number,
    model: string,
    brand: string,
    regno: string,
    dailyRate: number,
    year: number,
    color: string,
    carImage: string
}