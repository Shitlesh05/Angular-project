import { Routes } from '@angular/router';
import { Admin1Component } from './components/admin1/admin1.component';
import { DataBinding3Component } from './components/data-binding3/data-binding3.component';
import { NgClass5Component } from './components/ng-class5/ng-class5.component';
import { ControlStatement6Component } from './components/control-statement6/control-statement6.component';
import { Signal7Component } from './components/signal7/signal7.component';
import { LinkedSignal8Component } from './components/linked-signal8/linked-signal8.component';
import { TemplateForm9Component } from './components/template-form9/template-form9.component';
import { ReactiveForm10Component } from './components/reactive-form10/reactive-form10.component';
import { NgIf4Component } from './components/ng-if4/ng-if4.component';
import { NgStyle5Component } from './components/ng-style5/ng-style5.component';
import { NgFor4Component } from './components/ng-for4/ng-for4.component';
import { GetApiComponent } from './components/API-Integration/get-api/get-api.component';
import { PostApiComponent } from './components/API-Integration/post-api/post-api.component';
import { PutApiComponent } from './components/API-Integration/put-api/put-api.component';
import { DeleteApiComponent } from './components/API-Integration/delete-api/delete-api.component';
import { ResourceApiComponent } from './components/ResourceApi/resource-api/resource-api.component';
import { CustomerComponent } from './components/API-Integration/customer/customer.component';
import { LifecycleEvents11Component } from './components/lifecycle-events11/lifecycle-events11.component';
import { LifecycleExampleComponent } from './components/API-Integration/lifecycle-example/lifecycle-example.component';
import { Pipes12Component } from './components/pipes12/pipes12.component';
import { ResourceApi2Component } from './components/ResourceApi/resource-api2/resource-api2.component';
import { LoginComponent } from './components/LoginPagewithGuards12/login/login.component';
import { LayoutComponent } from './components/LoginPagewithGuards12/layout/layout.component';

export const routes: Routes = [
    {
        path:'',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path:'login',
        component:LoginComponent
    },
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: 'admin',
                component: Admin1Component
            },
            {
                path: 'dataBinding3',
                component: DataBinding3Component
            },
            {
                path: 'ng-if4',
                component: NgIf4Component
            },
            {
                path: 'ng-for4',
                component: NgFor4Component
            },
            {
                path: 'ng-style5',
                component: NgStyle5Component
            },
            {
                path: 'ng-class5',
                component: NgClass5Component
            },
            //control statements
            {
                path: 'control-flow',
                component: ControlStatement6Component
            },
            // signals
            {
                path: 'signal',
                component: Signal7Component
            },
            //linked signal
            {
                path: 'linked-signal',
                component: LinkedSignal8Component
            },
            //template-form
            {
                path: 'template-form',
                component: TemplateForm9Component
            },
            //reactive-form
            {
                path: 'reactive-form',
                component: ReactiveForm10Component
            },
            {
                path: 'get-api',
                component: GetApiComponent
            },
            {
                path: 'post-api',
                component: PostApiComponent
            },
            {
                path: 'put-api',
                component: PutApiComponent
            },
            {
                path: 'delete-api',
                component: DeleteApiComponent
            },
            {
                path: 'resource-api',
                component: ResourceApiComponent
            },
            {
                path: 'customer',
                component: CustomerComponent
            },
            {
                path: 'lifecycle-events',
                component: LifecycleEvents11Component
            },
            {
                path: 'lifecycle-example',
                component: LifecycleExampleComponent
            },
            {
                path: 'pipes',
                component: Pipes12Component
            },
            {
                path: 'custom-pipes',
                component: Pipes12Component
            },
            {
                path: 'resource-api2',
                component: ResourceApi2Component
            }
        ]
    }
];
