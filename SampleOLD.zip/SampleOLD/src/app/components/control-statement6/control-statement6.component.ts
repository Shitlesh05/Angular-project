import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-control-statement6',
  imports: [FormsModule],
  templateUrl: './control-statement6.component.html',
  styleUrl: './control-statement6.component.css'
})
export class ControlStatement6Component {

  div1visible: boolean = true;
  isChecked: boolean = false;
  dayName: string = '';

  cityList: string [] = [
    "Pune",
    "Mumbai",
    "Hyderabad",
    "Chennai",
    "Bangalore"
  ]; 

  employeeList: any[] = [
    {empId: 111, name:'ABC', city:"Pune", contact:"9876543210"},
    {empId: 222, name:'ABCD', city:"Nagpur", contact:"0123456789"},
    {empId: 333, name:'ABCDE', city:"Hyderabad", contact:"1597538524"},
    {empId: 444, name:'ABCDEF', city:"Chennai", contact:"3579518426"},
    {empId: 555, name:'ABCDEFG', city:"Bangalore", contact:"8524569173"}
  ]

  hideShowDiv1(isShow: boolean){
    this.div1visible = isShow;
  }

}
