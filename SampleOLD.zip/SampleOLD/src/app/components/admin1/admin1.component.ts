import { JsonPipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProgressBarComponent } from '../reusable12/progress-bar/progress-bar.component';

@Component({
  selector: 'app-admin1',
  imports: [RouterLink],
  templateUrl: './admin1.component.html',
  styleUrl: './admin1.component.css'
})
export class Admin1Component {

}
