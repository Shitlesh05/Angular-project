import { Component } from '@angular/core';

@Component({
  selector: 'app-user1',
  imports: [],
  template: "<h2>User1 page</h2> <p class='text-danger'>Hi from User</p>",
  styles:['.text-danger {color: blue}']
})
export class User1Component {

}
