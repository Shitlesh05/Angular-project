import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-ng-class5',
  imports: [CommonModule,FormsModule],
  templateUrl: './ng-class5.component.html',
  styleUrl: './ng-class5.component.css'
})
export class NgClass5Component {

  div1BgColor: string = 'bg-success';
  isChecked: boolean = false;
  div3ClassName: string = '';

  addDiv1Color(className: string){
    this.div1BgColor = className;
  }

}
