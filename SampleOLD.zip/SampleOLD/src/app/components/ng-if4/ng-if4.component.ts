import { CommonModule, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ng-if4',
  imports: [NgIf,FormsModule],
  templateUrl: './ng-if4.component.html',
  styleUrl: './ng-if4.component.css'
})
export class NgIf4Component {

  div1Visible: boolean = false;
  number1: string = "";
  number2: string = "";



  hideDiv1(){
    this.div1Visible = false;
  }

  showDiv1(){
    this.div1Visible = true;
  }
}
