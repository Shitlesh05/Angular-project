import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceApi2Component } from './resource-api2.component';

describe('ResourceApi2Component', () => {
  let component: ResourceApi2Component;
  let fixture: ComponentFixture<ResourceApi2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResourceApi2Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResourceApi2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
