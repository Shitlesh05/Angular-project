import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-lifecycle-events11',
  imports: [],
  templateUrl: './lifecycle-events11.component.html',
  styleUrl: './lifecycle-events11.component.css'
})
export class LifecycleEvents11Component implements OnInit,AfterViewInit
,AfterViewChecked,AfterContentInit,AfterContentChecked, OnDestroy {

  constructor(){
    console.log("Constructor");
  }

  ngOnInit(): void {
    console.log("ngOnInit"); // triggered when component is initialized used for api call func
  }

  ngAfterContentInit(): void {
    console.log("ngAfterContentInit"); // triggered when external content is initialize
  }

  ngAfterContentChecked(): void {
    console.log("ngAfterContentChecked"); // triggered when external contents are loaded
  }

  ngAfterViewInit(): void {
    console.log("ngAfterViewInit", performance.now()); //triggred when all the view (template or another components) are initialized
  } // viewchild, getting reference of element

  ngAfterViewChecked(): void {
    console.log("ngAfterViewChecked"); // triggered when all the views(template or another components) are initilaized and checked 
  }

  ngOnDestroy(): void {
    alert("You are redirecting to diffrent page")
    console.log("ngOnDestroy"); // triggered when we redirect to another component current component will destroy
  }

}
