import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LifecycleEvents11Component } from './lifecycle-events11.component';

describe('LifecycleEvents11Component', () => {
  let component: LifecycleEvents11Component;
  let fixture: ComponentFixture<LifecycleEvents11Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LifecycleEvents11Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LifecycleEvents11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
