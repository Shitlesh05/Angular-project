import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateForm9Component } from './template-form9.component';

describe('TemplateForm9Component', () => {
  let component: TemplateForm9Component;
  let fixture: ComponentFixture<TemplateForm9Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TemplateForm9Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplateForm9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
