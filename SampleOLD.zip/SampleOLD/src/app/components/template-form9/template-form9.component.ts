import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-template-form9',
  imports: [FormsModule,NgIf],
  templateUrl: './template-form9.component.html',
  styleUrl: './template-form9.component.css'
})
export class TemplateForm9Component {
  userObj: any = {
    firstName: "",
    lastName: '',
    username:'',
    city:'',
    state:'Goa',
    zipCOde:'',
    isTermsAgree: false
  }

  onSave(){
    //debugger;
    const form = this.userObj;
  }

}
