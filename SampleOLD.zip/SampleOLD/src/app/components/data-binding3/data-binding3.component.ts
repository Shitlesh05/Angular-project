import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-data-binding3',
  imports: [FormsModule],
  templateUrl: './data-binding3.component.html',
  styleUrl: './data-binding3.component.css'
})
export class DataBinding3Component {

  firstName: string = "Shitlesh";
  rollNo: number = 7;
  isActive: boolean = true;
  currentDate: Date = new Date();
  myPlaceholder: string = "Enter full name";
  divClassName: string = "bg-primary";
  selectCity: string = "";

  constructor(private router: Router) {
    console.log(this.firstName);
    this.isActive = false;
    console.log(this.isActive);
  }

  showWelcomemsg(){
    alert("Welcome to Angular 19")
  }

  onCityChange(){
    console.log("City Changed......!")
  }

  navigatetoAdmin(){
    this.router.navigateByUrl("/admin");
  }

}
