import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveForm10Component } from './reactive-form10.component';

describe('ReactiveForm10Component', () => {
  let component: ReactiveForm10Component;
  let fixture: ComponentFixture<ReactiveForm10Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveForm10Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReactiveForm10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
