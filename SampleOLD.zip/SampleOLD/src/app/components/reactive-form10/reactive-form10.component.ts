import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form10',
  imports: [ReactiveFormsModule],
  templateUrl: './reactive-form10.component.html',
  styleUrl: './reactive-form10.component.css'
})
export class ReactiveForm10Component {

  userForm: FormGroup = new FormGroup ({
    fName: new FormControl("",[Validators.required]),
    lName: new FormControl("",[Validators.required, Validators.minLength(4)]),
    userName: new FormControl("",[Validators.email]),
    city: new FormControl(""),
    state: new FormControl("Goa"),
    zipCode: new FormControl(""),
    isAgree: new FormControl(false)
  })

 constructor(){
  this.userForm.controls['state'].disable();
  setTimeout(() => {
    this.userForm.controls['state'].enable();
  },3000);

  //to check form is valid
  
 }
  onUserSave(){
    const isValid = this.userForm.valid;
    const formVal = this.userForm.value;
    debugger;
  }

}
