import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgFor4Component } from './ng-for4.component';

describe('NgFor4Component', () => {
  let component: NgFor4Component;
  let fixture: ComponentFixture<NgFor4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NgFor4Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgFor4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
