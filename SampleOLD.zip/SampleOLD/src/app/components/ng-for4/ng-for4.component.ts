import { NgFor } from '@angular/common';
import { Component } from '@angular/core';
import { ProgressBarComponent } from "../reusable12/progress-bar/progress-bar.component";

@Component({
  selector: 'app-ng-for4',
  imports: [NgFor, ProgressBarComponent],
  templateUrl: './ng-for4.component.html',
  styleUrl: './ng-for4.component.css'
})
export class NgFor4Component {

  cityList: string[] = ["Pune", "Nagpur", "Mumbai", "Hyderabad", "Chennai"]

  employeeList: any[] = [
    {empId: 111, name:'ABC', city:"Pune", contact:"9876543210",attendance:50},
    {empId: 222, name:'ABCD', city:"Nagpur", contact:"0123456789",attendance:70},
    {empId: 333, name:'ABCDE', city:"Hyderabad", contact:"1597538524",attendance:80},
    {empId: 444, name:'ABCDEF', city:"Chennai", contact:"3579518426",attendance:40},
    {empId: 555, name:'ABCDEFG', city:"Bangalore", contact:"8524569173",attendance:100}
  ]

}
