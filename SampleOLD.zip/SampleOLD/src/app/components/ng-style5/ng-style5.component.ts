import { NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ng-style5',
  imports: [NgStyle,FormsModule],
  templateUrl: './ng-style5.component.html',
  styleUrl: './ng-style5.component.css'
})
export class NgStyle5Component {

  div1BgColor: string = '';

  myCss: any = {
    'background-color':'gray',
    'width':'200px',
    'height':'200px'
  }

  addDiv1Color(color: string){
    this.div1BgColor = color;
  }

  isChecked: boolean = false;

}
