import { ChangeDetectionStrategy, Component, signal } from '@angular/core';

@Component({
  selector: 'app-signal7',
  imports: [],
  templateUrl: './signal7.component.html',
  styleUrl: './signal7.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Signal7Component {

  firstName = signal("Shitlesh");
  lastName = signal<string>("Kaloshiya");

  courseName: string = "Angular";
  rollNo = signal<number>(0);

  constructor(){
    const val = this.firstName();
    setTimeout(() => {
      //debugger;
      this.courseName = "React";
      this.firstName.set("Suraj");
      debugger;
    }, 5000);
  }

  onIncr(){
    this.rollNo.update(oldval => oldval+1);
  }

}
