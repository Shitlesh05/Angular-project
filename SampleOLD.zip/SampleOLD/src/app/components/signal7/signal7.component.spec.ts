import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Signal7Component } from './signal7.component';

describe('Signal7Component', () => {
  let component: Signal7Component;
  let fixture: ComponentFixture<Signal7Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Signal7Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Signal7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
