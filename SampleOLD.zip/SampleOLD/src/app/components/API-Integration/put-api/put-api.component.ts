import { JsonPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-put-api',
  imports: [FormsModule],
  templateUrl: './put-api.component.html',
  styleUrl: './put-api.component.css'
})
export class PutApiComponent {

  carList: any[] = [];

  http = inject(HttpClient);

  carObj: any = {
    "id": 0,
    "model": '',
    "brand": '',
    "regno":'',
    "dailyRate": '',
    "year": '',
    "color":'',
    "carImage":''
  };

  isEdit = false;

  getAllCars(){
    this.http.get("http://localhost:3000/cars").subscribe((result:any) => {
      this.carList = result;
    })
  }

  
  onSaveCars(){
    debugger;
    this.http.post("http://localhost:3000/cars",this.carObj)
    // .subscribe((response:any) => {
    //  debugger;
    //  if(response.result) {
    //   alert("Car created Successfully");
    //   this.getAllCars();
    //  } else {
    //   alert(response.message)
    //  }
    // })
    .subscribe({
      next: (response: any) => {
        alert("Car created successfully!");
        this.getAllCars();  
      },
      error: (err) => {
        alert("Failed to create car");
      }
    });
  }

  onEdit(data: any){
    this.carObj = { ...data };
  }

  onUpdateCars(){
    this.http.put(`http://localhost:3000/cars/${this.carObj.id}`,this.carObj)
    // .subscribe((response:any) => {
    //  debugger;
    //  if(response.result) {
    //   alert("Car Updated Successfully");
    //   this.getAllCars();
    //  } else {
    //   alert(response.message)
    //  }
    // })
    .subscribe({
      next: (response: any) => {
        alert("Car Updated successfully!");
        this.getAllCars();  
      },
      error: (err) => {
        alert("Failed to update car");
      }
    });
  }

  onDeleteCars(id: number){
    const isDelete = confirm("Are you sure you want to delete?");
    if(isDelete == true){
      this.http.delete(`http://localhost:3000/cars/${id}`)
      .subscribe((response:any) => {
     debugger;
     if(response.result) {
      alert("Car Deleted Successfully");
      this.getAllCars();
     } else {
      alert(response.message)
     }
    })
    }
  }
  

}
