import { Component } from '@angular/core';

@Component({
  selector: 'app-put1-api',
  imports: [],
  templateUrl: './put1-api.component.html',
  styleUrl: './put1-api.component.css'
})
export class Put1ApiComponent {

}
