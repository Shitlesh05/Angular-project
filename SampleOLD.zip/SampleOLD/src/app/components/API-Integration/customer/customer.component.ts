import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CustomerService } from '../../../Services/customer.service';
import { ProgressBarComponent } from "../../reusable12/progress-bar/progress-bar.component";
import { TabsComponent } from "../../reusable12/tabs/tabs.component";

@Component({
  selector: 'app-customer',
  imports: [FormsModule, ProgressBarComponent, TabsComponent],
  templateUrl: './customer.component.html',
  styleUrl: './customer.component.css'
})
export class CustomerComponent {

  custTabs: string[] = ["Basic Info","Plan Info","Payments"];

  custList: any [] = [];
  custObj: any = {
    "customerId": 0,
    "customerName": "",
    "customerCity": "",
    "mobileNo": "",
    "email": ""
  }

  constructor(private custService: CustomerService){
    this.getCustomers();
  }

  getCustomers(){
    //debugger;
    this.custService.loadCust().subscribe((result:any) => {
      //debugger;
      this.custList = result;
    })
  }

  onSaveCustomer(){
    this.custService.createNewCust(this.custObj)
    .subscribe({
      next: (response: any) => {
        //debugger;
        alert("Customer created successfully!");
        this.getCustomers();  
      },
      error: (err) => {
        alert("Failed to create customer");
      }
    });
  }

  

}
